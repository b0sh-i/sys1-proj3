/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE 
* STRICTLY ADHERED TO THE TENURES OF THE 
* OHIO STATE UNIVERSITY'S ACADEMIC INTEGRITY POLICY. 
 */
#include <stdio.h>
#include <stdlib.h>
#include "project3.h"

// Prompt the user for siz of book list, make an array contanining all of the books
int read_titles(char ***list_of_books) {
  int number_of_books;
  scanf("%d", &number_of_books);

  char **book_titles = calloc(number_of_books, sizeof(char*));
  if (number_of_books >= 1) {
    printf("Enter the %d book titles one to a line: ", number_of_books);
    for (int i = 0; i < (int)number_of_books; i++) {
      add_to_array(book_titles + i);
    }
  }

  *list_of_books = book_titles;
  // Return the number of books for later use
  return number_of_books;
}
